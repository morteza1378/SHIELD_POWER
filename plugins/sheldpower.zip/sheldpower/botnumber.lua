do
function run(msg, matches)
send_contact(get_receiver(msg), "+14253585209", "c_r_f", "BOT", ok_cb, false)
end
return {
patterns = {
"^!botnumber$"
},
run = run
}

end