local function run(msg)
if msg.text == "morteza" then
 return "😍❤️با بابام چیکار داری؟"
end
if msg.text == "مرتضی" then
 return "😍❤️با بابام چیکار داری؟"
end
if matches[1]:lower() == "slm" and is_sudo(msg) then
return "سلامـ  بابایـ  خوشگلمـ 🌝"
end
if matches[1]:lower() == "bye"  or "bedrood" or "bdrod" or "bdrood" or "bedrud" or "بای" and is_sudo(msg) then
return "خدافس باباجونیـ ●…●‌"
end
if matches[1]:lower() == "سلام" and is_sudo(msg) then 
return "سلامـ باباجونیـ خوشگلمـ"
end
if matches[1]:lower() == "سلام" and not is_sudo(msg) then
return "سلام"
end
if matches[1]:lower() == "bye" or "بای" and not is_sudo(msg) then
return "خدافس"
end
end

return {
 description = "Chat With Robot Server", 
 usage = "chat with robot",
 patterns = {
  "slm$",
  "bye$",
  "بای$",
  "سلام$",
   "[Mm]orteza$",
   "مرتضی$"
  }, 
 run = run,
    --privileged = true,
 pre_process = pre_process
}
