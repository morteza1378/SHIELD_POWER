do

local function run(msg, matches)
  if matches[1]:lower() == 'help' or 'راهنما' then --change this with anything you want
      return [[ 
  

🔮راهنمای سوپر گروه🔮:


▪️حذف کردن کاربر

🔴kick [يوزرنيم/يوزر آي دي]

▪️بن کردن کاربر

🔴ban [يوزرنيم/يوزر آي دي]

▪️ حذف بن کاربر ( آن بن )

🔴unban [يوزرنيم/يوزر آي دي]
 

▪️حذف خودتان از گروه

🔴kickme

▪️ دريافت ليست مديران گروه

🔴mods

▪️افزودن يک مدير به گروه

🔴modp [يوزرنيم/يوزر آي دي]
▪️ حذف کردن يک مدير

🔴moddem [يوزرنيم/يوزر آي دي]
 
▪️تغيير حساسيت ضد اسپم

🔴setflood [5-20] انتخاب و قفل عکس گروه

🔴setphoto
 ▪️انتخاب نام گروه

🔴setname [نام مورد نظر]

▪️ انتخاب قوانين گروه

🔴setrules [متن قوانين]

▪️ انتخاب توضيحات گروه

🔴setabout [متن مورد نظر]

▪️ قفل اعضا ، نام گروه ، ربات و ...
🔴lock [links|tag|user|spam|arabic|🔴member|sticker|contacts]

▪️باز کردن قفل اعضا ، نام گروه و ...

🔴unlock [links|tag|user|spam|
arabic|member|sticker|contacts]

 ▪️بي صدا کردن يک حالت

🔴mute [chat|audio|gifs|photo|video]

▪️ با صدا کردن يک حالت

🔴unmute [chat|audio|gifs|photo|video]

▪️ بي صدا کردن فردي توسط ريپلي
(براي غير فعالسازي دستور بي صدا
کردن کاربر ، دوباره کد را ارسال کنيد)

🔴mute

▪️ دريافت ليست افراد بي صدا شده

🔴muteslist

▪️حذف يک پيام توسط ريپلي

🔴del

▪️ اضافه کردن يک کلمه به ليست فيلتر

🔴/addword [کلمه]

▪️حذف يک کلمه از ليست فيلترينگ 

🔴/rw [کلمه]

 ▪️دريافت ليست فيلترينگ 

🔴/badwords

▪️حذف پيام هاي اخير گروه

🔴rmsg (عددي زير 1000)

▪️دريافت يوزر آي دي گروه يا کاربر

🔴id

▪️دريافت اطلاعات کاربري و مقام

🔴info|wai|me|من کيم
 
▪️قوانين گروه

🔴rules

▪️ تعيين عمومي بودن يا نبودن گروه

🔴public [yes/no]

▪️دريافت تنظيمات گروه 

🔴settings
 
▪️ساخت / تغيير لينک گروه

🔴newlink 

▪️ تعيين لينک گروه

🔴setlink

 ▪️دريافت لينک گروه

🔴link

▪️ دريافت لينک گروه در پي وي

🔴linkpv

▪️ سيو کردن يک متن

🔴/save [value] <text>

▪️دريافت متن سيو شده

🔴[value]

▪️ حذف قوانين ، مديران ، اعضا و ...

🔴c [modlist|rules|about]

▪️دريافت يوزر آي دي يک کاربر

🔴id [يوزنيم]

 ▪️دريافت ليست کاربران بن شده

🔴banlist

▪️ ارسال پيام به مدير ربات


⚫️نظر[متن پيام]

 
▪️دريافت اطلاعات ربات

🔴ver

🔴warn|unwarn

▪️زيبا نويسي متن

🔴write [text]
🔸🔹🔹🔶🔷🔺🔷🔶🔹
🔵💙 ليست دستورات تفریحی ❤️:

�helpfun

➖➖➖➖➖➖➖
Team Channel : @Shield_Tm
Sudo Users :  👤
@Xx_KinG_SuPeR_AdMiN_SHIELD_xX
@Xx_PesareShield_shah2Arvah_xX
=========================
🇸 🇭 🇮 🇪 🇱 🇩™

 ]]
  end
end

return {
  patterns = {
    "^[!/#]([Hh]elp)$",
    "^([Hh]elp)$",
"^راهنما$",
    
    },
  run = run
}
end
