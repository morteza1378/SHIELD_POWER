do

function run(msg, matches)
 if msg.to.type == 'channel' and is_momod(msg) then
  return  [[
🔵💙 ليست دستورات تفریحی ❤️:

▪️دريافد عدد ابجد کلمه

🔴abjad [word]

▪️زيبا نويسي متن

🔴write [text]


🔴وضعیت (شهر|کشور)

🔹مشاهده وضعیت اب و هوای شهر یا کشور مورد نظر

🔴اینستا (یوزر)

🔹مشاهده اطلاعات ایستاگرام فرد مورد نظر

🔴زمان

🔹مشاهده تاریخ و ساعت

🔴من کیم

🔹مشاهده مقام خود در گروه

🔴!link (لینک)

🔹کوتاه کردن لینک مورد نظر

🔴write (متن)

🔹نوشتن متن انگلیسی با فونت زیبا

🔴حساب کن (معادله)

🔹حساب کردن معادله

🔹مثال :

🔵حساب کن 2+5

🔴ترجمه en (متن)

🔹ترجمه کردن متن فارسی به انگلیسی

🔹مثال :

🔵ترجمه en سلام

🔴 بگو (متن)

🔹تکرار متن

🔴 تبدیل (متن)

🔹تبدیل متن به عکس

🔴 جوک

🔹گفتن جوک

🔴 جملک 

🔹گفتن متن سنگین

➖➖➖➖➖➖➖
Team Channel : @Shield_Tm
Sudo Users :  👤
@Xx_KinG_SuPeR_AdMiN_SHIELD_xX
@Xx_PesareShield_shah2Arvah_xX
=========================
🇸 🇭 🇮 🇪 🇱 🇩™

]]
end
end

return {
  description = "Robot About", 
  usage = "help: View Robot About",
  patterns = {"^([Hh]elpfun)$",
"^راهنمای فان$",
}, 
  run = run 
}

end
