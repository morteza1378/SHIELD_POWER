local test = {
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9",
"0",
}
local testt = {
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9",
"0",
}
local testtt = {
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9",
"0",
}
local testttt = {
"1",
"2",
"3",
"4",
"5",
"6",
"7",
"8",
"9",
"0",
}
local function run(msg)
local o = test[math.random(#test)]
local t = testt[math.random(#testt)]
local h = testtt[math.random(#testtt)]
local f = testttt[math.random(#testttt)]
return 'pass :\n'..o..t..h..f
end
return {
patterns = {
"^pass$"
},
run = run
}