do

local function run(msg, matches)
  if matches[1]:lower() == 'shield' or 'شیلد' then --change this with anything you want
      return [[ 
  
    🤖 C R F BoT  ♈️ FINAL

    Advanced ManagerBot Based On TeleSeed
=========================
    
   ✏ Edited By :

   ⭐ سازنده ربات : 

                               👤

@Xx_KinG_SuPeR_AdMiN_SHIELD_xX

@Xx_PesareShield_shah2Arvah_xX

✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚
    
   🆔 Our Telegram Channel ID :

   ⭐ کانال رسمی ما :

   ❇ @Shield_Tm

✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚
  
   👥 Speacial Thanks To My friends :

   ⭐ تشکر از کسانی که حمایت کردند :
   👤@Reza_Poker
--------------------------------------
   👤@SoLiD021
--------------------------------------
   👤@heismahdi
--------------------------------------
   👤@arisharr
--------------------------------------
    and other that help me for this Bot

   ⭐ و دیگر دوستانی که به ما کمک کردند

✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚✚

    📬 our massage bot :

   ⭐ ربات پیام رسان ما :  

    ✳ @Shieldmassage_bot

=========================
🇸 🇭 🇮 🇪 🇱 🇩™


 ]]
  end
end

return {
  patterns = {
    "^[!/#]([Ss]hield)$",
    "^([Ss]hield)$",
"^شیلد$",
    
    },
  run = run
}
end