do
local function run(msg, matches)
    local morteza = آیدی اولین سودو
    local pedi = آیدی دومین سودو
    local morech = آیدی سومین سودو 
    
      if msg.text:find('cart') then
          if msg.from.id == tonumber(raman) then
        local text = [[

🔖Name : 💀ʀαмαɴ💀
🔖 Last name: ——
🔖Age: 15
🔖 Username: @Pro_Dev
🔖Phone number: +98903078****
⭐️ Team name: MuteTeam & Magic
📊 Level: 5
📝Status: Editor & Developer

        ]]
 send_document(get_receiver(msg), "/home/DBTeam/data/sticker/226202584.webp", ok_cb, false)

    return text
    
      else if msg.from.id == tonumber(Mohammad) then
        local text = [[

🔖Name : Mohammad
🔖 Last name: ——
🔖Age: 16
🔖 Username: 
🔖Phone number: +98939830**** 
⭐️ Team name: MuteTeam
📊 Level: 2
📝Status: Editor & Developer

        ]]
 send_document(get_receiver(msg), "/home/DBTeam/data/sticker/206596952.webp", ok_cb, false)

    return text

      else  if msg.from.id == tonumber(mutepuker) then

    local text = [[
 🔖Name : MutePuker
🔖 Last name: ——
🔖Age: 17
🔖 Username: @MutePuker
🔖Phone number: +98921122**** 
⭐️ Team name: MuteTeam
📊 Level: 2
📝Status: hi all ;)
im MutePuker !
im low developer :)
my love PHP 🙈
        ]]
   send_document(get_receiver(msg), "/home/DBTeam/data/sticker/203939937.webp", ok_cb, false)
        return text
    else  if not is_sudo(msg) then
          return "🔖شما جزء تیم ..... نیستید یا کارت شناسایی برای شما صادر نشده است"


   end
      end 
          end 
                end
                 end
                 end

return {
  patterns = {
    "^[!#/][Cc][Aa][Rr][Tt]$",
    "^([Cc]art)$",
    },
  run = run
}
end