function run(msg, matches)
  return [[C R F BoT
  
  Bot Version : FINAL
  
  For more Information send /shield to chat ]]
end

return {
  description = "Shows bot version", 
  usage = "!version: Shows bot version",
  patterns = {
    "^[!/]version$",
    "^[!/]ver$",
"^ورژن$",
    "^[Vv]ersion$",
    "^[Vv]er$"
  }, 
  run = run 
}